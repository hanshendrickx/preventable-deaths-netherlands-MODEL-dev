export default function Page() {
  return (
    <div className="min-h-screen bg-background">
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          <header className="text-center space-y-4">
            <h1 className="text-4xl font-bold tracking-tight">International Preventable Deaths Analysis Model</h1>
            <p className="text-xl text-muted-foreground">Netherlands Implementation</p>
          </header>

          <div className="prose prose-neutral dark:prose-invert max-w-none">
            <section className="space-y-4">
              <h2 className="text-2xl font-semibold">Overview</h2>
              <p className="text-muted-foreground leading-relaxed">
                A comprehensive framework for analyzing preventable mortality across different healthcare systems, with
                initial implementation for the Netherlands. This project provides a systematic approach to identifying,
                categorizing, and analyzing preventable deaths within healthcare systems.
              </p>
            </section>

            <section className="space-y-4 mt-8">
              <h2 className="text-2xl font-semibold">Key Features</h2>
              <ul className="space-y-2 text-muted-foreground">
                <li>Interactive data visualization of preventable death statistics</li>
                <li>Comparative analysis across different healthcare categories</li>
                <li>Temporal trend analysis</li>
                <li>Evidence-based categorization framework</li>
                <li>Cross-national comparison capabilities</li>
              </ul>
            </section>

            <section className="space-y-4 mt-8">
              <h2 className="text-2xl font-semibold">Citation</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Hendrickx, H., Junger, M., & v0 by Vercel (2025). International Preventable Deaths Analysis Model:
                Netherlands Implementation. A Framework for Cross-National Comparison of Preventable Mortality.
              </p>
            </section>
          </div>
        </div>
      </main>
    </div>
  )
}
